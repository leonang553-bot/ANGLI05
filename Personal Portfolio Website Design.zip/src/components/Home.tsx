import { Github, Linkedin, Mail, Briefcase, Users, FileText } from 'lucide-react';
import profileImage from 'figma:asset/ba378b6b419f8e7ce9775ce8a9b1de43a633cc3b.png';
import ActivityCard from './ActivityCard';
import Tag from './Tag';

export default function Home() {
  const activities = [
    {
      icon: <Users className="w-5 h-5" />,
      title: 'International Mentor, Lund University',
      description: 'Onboarding & cultural/community events for new students.',
    },
    {
      icon: <Briefcase className="w-5 h-5" />,
      title: 'Private Equity Product Assistant (Fengjing Capital)',
      description: 'Product issuance & compliance, data ops, due diligence, roadshow/marketing materials, WeChat & website content.',
    },
    {
      icon: <FileText className="w-5 h-5" />,
      title: 'Consulting Practical Training',
      description: 'Biotech digital transformation proposal — platform benchmarks, pricing frameworks, marketing plan, policy/regulatory scan.',
    },
  ];

  const interests = [
    { emoji: '⚽', label: 'Football' },
    { emoji: '🏸', label: 'Badminton' },
    { emoji: '⛳', label: 'Golf' },
    { emoji: '✈️', label: 'Traveling' },
    { emoji: '📚', label: 'Comics' },
  ];

  const skills = [
    'Stata',
    'Excel',
    'PowerPoint',
    'Python (basic)',
    'Research & Writing',
  ];

  return (
    <main className="pt-24 pb-16 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Hero Section */}
        <section className="mb-16">
          <img
            src={profileImage}
            alt="Ang Li"
            className="w-52 h-52 rounded-full mb-6 object-cover shadow-lg border-4 border-white dark:border-[#252A34]"
          />
          <h1 className="mb-6 text-5xl font-bold">Ang Li</h1>
          <p className="max-w-2xl mb-8 text-[#E4E6EB] leading-relaxed">
            Undergraduate in Economy & Society at Lund University. I'm interested in economic history, 
            demography, and how media influences fertility decisions. I've worked on private equity 
            product operations and consulting research across policy, markets, and go-to-market strategy.
          </p>

          {/* Social Links */}
          <div className="flex flex-col gap-2 mb-4">
            <a
              href="https://github.com/your-username"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-[#E4E6EB] hover:text-[#60A5FA] transition-all duration-200"
            >
              <Github size={20} />
              <span>GitHub</span>
            </a>
            <a
              href="https://www.linkedin.com/in/ang-li-079012327"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-[#E4E6EB] hover:text-[#60A5FA] transition-all duration-200"
            >
              <Linkedin size={20} />
              <span>LinkedIn</span>
            </a>
            <a
              href="mailto:LEON050417@outlook.com"
              className="flex items-center gap-2 text-[#E4E6EB] hover:text-[#60A5FA] transition-all duration-200"
            >
              <Mail size={20} />
              <span>LEON050417@outlook.com</span>
            </a>
          </div>
        </section>

        {/* Activities & Achievements */}
        <section className="mb-12">
          <h2 className="mb-6">Activities & Achievements</h2>
          <div className="space-y-4">
            {activities.map((activity, index) => (
              <ActivityCard key={index} {...activity} />
            ))}
          </div>
        </section>

        {/* Skills */}
        <section className="mb-12">
          <h2 className="mb-4">Skills</h2>
          <div className="flex flex-wrap gap-3">
            {skills.map((skill, index) => (
              <Tag key={index} label={skill} />
            ))}
          </div>
        </section>

        {/* Interests & Hobbies */}
        <section>
          <h2 className="mb-4">Interests & Hobbies</h2>
          <div className="flex flex-wrap gap-3">
            {interests.map((interest, index) => (
              <Tag key={index} emoji={interest.emoji} label={interest.label} />
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}