import { FileText } from 'lucide-react';
import { Link } from 'react-router-dom';
import { blogPosts } from '../data/blogPosts';

export default function Blog() {
  return (
    <main className="pt-24 pb-16 px-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="mb-12">Blog</h1>
        
        {blogPosts.length > 0 ? (
          <div className="space-y-8">
            {blogPosts.map((post) => (
              <Link
                key={post.id}
                to={`/blog/${post.id}`}
                className="block group"
              >
                <article className="border border-[#3A3F4B] rounded-xl p-6 transition-all duration-200 hover:border-[#60A5FA]">
                  <h2 className="mb-3 text-3xl font-bold group-hover:text-[#60A5FA] transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-sm text-[#9CA3AF] mb-3">{post.date}</p>
                  <p className="text-[#E4E6EB] leading-relaxed">
                    {post.excerpt}
                  </p>
                </article>
              </Link>
            ))}
          </div>
        ) : (
          <div className="bg-[#252A34] rounded-2xl p-12 text-center transition-all duration-300 hover:shadow-lg">
            <FileText className="w-16 h-16 mx-auto mb-6 text-[#60A5FA]" />
            <p className="text-[#E4E6EB] max-w-2xl mx-auto leading-relaxed">
              Blog posts coming soon! I'll write about economic history, demography, media & fertility, 
              and practical notes from finance/consulting work.
            </p>
          </div>
        )}
      </div>
    </main>
  );
}