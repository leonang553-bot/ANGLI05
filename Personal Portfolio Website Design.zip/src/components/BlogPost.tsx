import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { blogPosts } from '../data/blogPosts';

export default function BlogPost() {
  const { id } = useParams<{ id: string }>();
  const post = blogPosts.find(p => p.id === id);

  if (!post) {
    return (
      <main className="pt-24 pb-16 px-6">
        <div className="max-w-3xl mx-auto">
          <Link
            to="/blog"
            className="inline-flex items-center gap-2 text-[#E4E6EB] hover:text-[#60A5FA] transition-colors mb-8"
          >
            <ArrowLeft size={20} />
            Back to Blog
          </Link>
          <h1>Post not found</h1>
        </div>
      </main>
    );
  }

  return (
    <main className="pt-24 pb-16 px-6">
      <div className="max-w-3xl mx-auto">
        <Link
          to="/blog"
          className="inline-flex items-center gap-2 text-[#E4E6EB] hover:text-[#60A5FA] transition-colors mb-8"
        >
          <ArrowLeft size={20} />
          Back to Blog
        </Link>
        
        <article className="border border-[#3A3F4B] rounded-xl p-8">
          <h1 className="mb-4 text-4xl font-bold">{post.title}</h1>
          <p className="text-sm text-[#9CA3AF] mb-8">{post.date}</p>
          
          <div className="prose prose-invert max-w-none">
            {post.content.split('\n\n').map((paragraph, index) => (
              <p key={index} className="mb-6 text-[#E4E6EB] leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>
        </article>
      </div>
    </main>
  );
}