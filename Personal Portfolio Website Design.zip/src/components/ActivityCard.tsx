interface ActivityCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export default function ActivityCard({ icon, title, description }: ActivityCardProps) {
  return (
    <div className="flex gap-3">
      <div className="flex-shrink-0 mt-1 text-[#60A5FA]">
        {icon}
      </div>
      <div className="flex-1">
        <h3 className="mb-1">{title}</h3>
        <p className="text-[#E4E6EB]">{description}</p>
      </div>
    </div>
  );
}