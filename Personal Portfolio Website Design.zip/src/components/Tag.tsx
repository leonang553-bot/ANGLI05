interface TagProps {
  emoji?: string;
  label: string;
}

export default function Tag({ emoji, label }: TagProps) {
  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#252A34] border border-[#3A3F4B] rounded-full text-[#E4E6EB]">
      {emoji && <span>{emoji}</span>}
      <span>{label}</span>
    </span>
  );
}